package com.example.pr_22_rom_kir_new_card

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editText = findViewById<EditText>(R.id.tb_your_card_number)

        // Регулярные выражения для различных типов карт
        val visaPattern = "^4[0-9]{2,12}(?:[0-9]{3})?$".toRegex()


        editText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable) {
                val cardNumber = s.toString()
                if (visaPattern.matches(cardNumber)) {
                    // Номер карты соответствует одному из регулярных выражений
                    Toast.makeText(applicationContext, "Номер карты валиден", Toast.LENGTH_SHORT).show()
                } else {
                    // Номер карты не соответствует регулярным выражениям
                    Toast.makeText(applicationContext, "Неверный номер карты", Toast.LENGTH_SHORT).show()
                }
            }
        })
    }
}
